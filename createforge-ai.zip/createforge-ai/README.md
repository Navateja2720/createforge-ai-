# CreateForge AI — Frontend Prototype

A responsive AI creative studio frontend concept featuring a dashboard, prompt composer, video editor demo, interactive Three.js 3D workspace, Blender-style workspace, project management, template library, and local file selection.

## Run it

Option 1: Open `index.html` in a modern browser. The 3D viewport loads Three.js from a CDN, so an internet connection is needed for that feature.

Option 2: Serve the folder locally:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Current prototype features

- Responsive dashboard and sidebar navigation.
- Prompt examples and creative mode switching.
- Project creation, search, and localStorage persistence.
- Local file selection and asset listing (files are not uploaded to a server).
- Video editing interface with sample timeline controls.
- Interactive Three.js 3D scene: orbit by dragging, zoom by scrolling, change color, add a cube, adjust rotation and light, export scene settings as JSON.
- Template gallery and demo AI assistant responses.

## Important limitations

This is a frontend prototype, not a production AI generation service. Prompt-to-video, prompt-to-3D, real AI edits, server storage, authentication, actual video rendering/export, payments, and full Blender integration are not connected. Demo responses are explicitly labeled. Add a backend and configure actual providers before production use.
